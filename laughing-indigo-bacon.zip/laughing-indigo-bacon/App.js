import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  Modal,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';

const MOCK_SUBTITLES = [
  { id: 1, original: "Welcome to this language learning tutorial.", start: 0, end: 4 },
  { id: 2, original: "Today we will learn how to build apps with Expo.", start: 4, end: 8 },
  { id: 3, original: "Dual subtitles make understanding much easier.", start: 8, end: 12 },
];

export default function App() {
  const [videoUrl, setVideoUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentSubIndex, setCurrentSubIndex] = useState(0);
  const [subtitles] = useState(MOCK_SUBTITLES);
  const [translatedSubs, setTranslatedSubs] = useState([]);
  const [targetLang] = useState('ar');

  const handleLoadAndTranslate = async () => {
    if (!videoUrl) return;
    setIsLoading(true);

    if (apiKey) {
      try {
        const response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{
                parts: [{
                  text: `Translate these subtitles to ${targetLang}. Return ONLY a JSON array of strings: ${JSON.stringify(subtitles.map(s => s.original))}`
                }]
              }]
            })
          }
        );
        const data = await response.json();
        if (data?.candidates?.[0]?.content?.parts?.[0]?.text) {
          const parsed = JSON.parse(data.candidates[0].content.parts[0].text);
          setTranslatedSubs(parsed);
        } else {
          fallbackTranslation();
        }
      } catch (err) {
        fallbackTranslation();
      }
    } else {
      fallbackTranslation();
    }
    setIsLoading(false);
  };

  const fallbackTranslation = () => {
    setTranslatedSubs([
      "مرحباً بكم في درس تعلم اللغات هذا.",
      "اليوم سنتعلم كيفية بناء التطبيقات باستخدام إكسبو.",
      "الترجمة المزدوجة تجعل الفهم أسهل بكثير."
    ]);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>DualSub Gemini</Text>
        <TouchableOpacity style={styles.settingsButton} onPress={() => setIsSettingsOpen(true)}>
          <Text style={styles.buttonText}>⚙️ Settings</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter video URL..."
          placeholderTextColor="#888"
          value={videoUrl}
          onChangeText={setVideoUrl}
        />
        <TouchableOpacity style={styles.loadButton} onPress={handleLoadAndTranslate}>
          <Text style={styles.buttonText}>Load</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.playerContainer}>
        {isLoading ? (
          <ActivityIndicator size="large" color="#4285F4" />
        ) : (
          <View style={styles.videoPlaceholder}>
            <Text style={styles.videoText}>
              {videoUrl ? `Video Player: ${videoUrl}` : "Enter video URL to start"}
            </Text>

            <View style={styles.subtitleOverlay}>
              <Text style={styles.primarySubtitle}>
                {subtitles[currentSubIndex]?.original || ""}
              </Text>
              <Text style={styles.translatedSubtitle}>
                {translatedSubs[currentSubIndex] || "Waiting for translation..."}
              </Text>
            </View>
          </View>
        )}
      </View>

      <View style={styles.controls}>
        <TouchableOpacity 
          disabled={currentSubIndex === 0}
          onPress={() => setCurrentSubIndex(prev => prev - 1)}
          style={[styles.stepButton, currentSubIndex === 0 && styles.disabled]}
        >
          <Text style={styles.buttonText}>Prev</Text>
        </TouchableOpacity>
        <Text style={styles.counter}>{currentSubIndex + 1} / {subtitles.length}</Text>
        <TouchableOpacity 
          disabled={currentSubIndex === subtitles.length - 1}
          onPress={() => setCurrentSubIndex(prev => prev + 1)}
          style={[styles.stepButton, currentSubIndex === subtitles.length - 1 && styles.disabled]}
        >
          <Text style={styles.buttonText}>Next</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={isSettingsOpen} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Settings</Text>
            <Text style={styles.label}>Gemini API Key:</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter Gemini API Key"
              placeholderTextColor="#888"
              value={apiKey}
              onChangeText={setApiKey}
              secureTextEntry
            />
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.saveButton} onPress={() => setIsSettingsOpen(false)}>
                <Text style={styles.buttonText}>Save & Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#121212', padding: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, marginTop: 30 },
  title: { color: '#FFF', fontSize: 20, fontWeight: 'bold' },
  settingsButton: { padding: 8, backgroundColor: '#2A2A2A', borderRadius: 6 },
  inputContainer: { flexDirection: 'row', marginBottom: 16, gap: 8 },
  input: { flex: 1, backgroundColor: '#1E1E1E', color: '#FFF', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 6, borderWidth: 1, borderColor: '#333' },
  loadButton: { backgroundColor: '#1A73E8', justifyContent: 'center', paddingHorizontal: 16, borderRadius: 6 },
  playerContainer: { height: 220, backgroundColor: '#000', borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  videoPlaceholder: { width: '100%', height: '100%', justifyContent: 'space-between', alignItems: 'center', padding: 12 },
  videoText: { color: '#666', marginTop: 30, fontSize: 12 },
  subtitleOverlay: { backgroundColor: 'rgba(0, 0, 0, 0.8)', padding: 8, borderRadius: 6, width: '100%', alignItems: 'center' },
  primarySubtitle: { color: '#FFF', fontSize: 13, marginBottom: 4, textAlign: 'center' },
  translatedSubtitle: { color: '#4DEEEA', fontSize: 15, fontWeight: '600', textAlign: 'center' },
  controls: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 },
  stepButton: { backgroundColor: '#2A2A2A', padding: 10, borderRadius: 6 },
  disabled: { opacity: 0.4 },
  counter: { color: '#888' },
  buttonText: { color: '#FFF', fontSize: 13 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.8)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#1E1E1E', padding: 20, borderRadius: 8 },
  modalTitle: { color: '#FFF', fontSize: 16, fontWeight: 'bold', marginBottom: 12 },
  label: { color: '#AAA', marginBottom: 8 },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 16 },
  saveButton: { backgroundColor: '#1A73E8', paddingVertical: 8, paddingHorizontal: 16, borderRadius: 6 },
});
